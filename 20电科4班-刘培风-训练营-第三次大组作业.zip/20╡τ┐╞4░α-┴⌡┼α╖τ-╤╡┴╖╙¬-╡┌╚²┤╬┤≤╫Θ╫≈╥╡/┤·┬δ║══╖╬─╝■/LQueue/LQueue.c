#include "LQueue.h"
#include "Input.h"

void InitLQueue(LQueue* Q)
{
	Q->front = Q->rear = (Node*)malloc(sizeof(Node));
	if (!Q->front)
	{
		printf("���붯̬�ڴ�ʧ�ܣ�\n");
		exit(0);
	}
	Q->front->next = NULL;//ͷ�ڵ㲻������
	Q->length = 0;
}

void DestoryLQueue(LQueue* Q)
{
	free(Q);
}

Status IsEmptyLQueue(const LQueue* Q)
{
	if (LengthLQueue(Q) == 0)
		return TRUE;
	return FALSE;
}

int LengthLQueue(LQueue* Q)
{
	return Q->length;
}

Status EnLQueue(LQueue* Q, void* data)
{
	Node* s = (Node*)malloc(sizeof(Node));
	s->data = (void*)malloc(20);
	memcpy(s->data, data, 20);
	if (!s)
	{
		printf("���붯̬�ڴ�ʧ�ܣ�\n");
		return FALSE;
	}
	s->next = NULL;
	Q->rear->next = s;
	Q->rear = s;
	Q->length++;
	return TRUE;
}

void ClearLQueue(LQueue* Q)
{
	Q->rear = Q->front;
	Q->rear->next = NULL;
	Q->length = 0;
}

int num;//ȫ�ֱ����������ж�datatype���±�

Status DeLQueue(LQueue* Q)
{
	if (IsEmptyLQueue(Q))
	{
		printf("����Ϊ�գ�\n");
		return FALSE;
	}
	printf("����");
	num = 0;
	LPrint(Q->front->next->data);
	printf("\n");
	Q->front = Q->front->next;
	Q->length--;
	return TRUE;
}

Status GetHeadLQueue(LQueue* Q, void* e)
{
	if (IsEmptyLQueue(Q))
	{
		printf("����Ϊ�գ�û�ж�ͷ��\n");
		return FALSE;
	}
	memcpy(e, Q->front->next->data, 20);//�����20
	return TRUE;
}

Status TraverseLQueue(const LQueue* Q, void (*foo)(void* q))
{
	if (IsEmptyLQueue(Q))
	{
		printf("����Ϊ�գ�\n");
		return FALSE;
	}
	Node* p = Q->front->next;
	num = 0;
	while (p->next != NULL)
	{
		foo(p->data);
		num++;
		p = p->next;
	}
	foo(p->data);
	return TRUE;
}

void LPrint(void* q)
{
	if (datatype[num] == '1')
		printf("%-5d ", *(int*)q);
	if (datatype[num] == '2')
		printf("%-8.3lf ", *(double*)q);
	if (datatype[num] == '3')
		printf("%-5c ", *(char*)q);
	if (datatype[num] == '4')
		printf("  %-13s ", (char*)q);
}

