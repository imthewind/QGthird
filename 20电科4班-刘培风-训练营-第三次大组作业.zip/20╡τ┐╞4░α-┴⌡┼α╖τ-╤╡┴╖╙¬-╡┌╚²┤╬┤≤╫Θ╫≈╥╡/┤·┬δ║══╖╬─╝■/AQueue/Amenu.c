#include "Amenu.h"
#include "Input.h"
#include <Windows.h>

void AQueue_Menu()
{
	int i = 0;
	char star = '*', empty = ' ';
	for (i = 0; i < 35; i++)
		printf("%c", empty);
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
	for (i = 0; i < 50; i++)
		printf("%c", star);
	printf("\n");
	for (i = 0; i <= 188 + 6 * 35; i++)
	{
		printf("%c", empty);
		if (i == 48) {
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 1);
			printf("��ӭʹ��˳����д洢��\n");
		}
		else if (i == 83) {
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
			printf("0��ˢ���б�\n");
		}
		else if (i == 118) {
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
			printf("1����ʼ��һ������\n");
		}
		else if (i == 153) {
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
			printf("2����ն���\n");
		}
		else if (i == 188) {
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
			printf("3�����ٶ���\n");
		}
		else if (i == 188 + 118 - 83)
		{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
			printf("4�����\n");
		}
		else if (i == 188 + 2 * 35 )
		{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
			printf("5������\n");
		}
		else if (i == 188 + 3 * 35)
		{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
			printf("6���鿴��ͷԪ��\n");
		}
		else if (i == 188 + 4 * 35)
		{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
			printf("7���鿴���г���\n");
		}
		else if (i == 188 + 5 * 35)
		{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
			printf("8����ӡ����\n");
		}
		else if (i == 188 + 6 * 35)
		{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
			printf("9���˳�\n");
		}
	}
	for (i = 0; i < 35; i++)
		printf("%c", empty);
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
	for (i = 0; i < 50; i++)
		printf("%c", star);
	printf("\n");
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);
}