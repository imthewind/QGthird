#include "AQueue.h"
#include "Input.h"

void InitAQueue(AQueue* Q)
{
	Q->front = 0;
	Q->rear = 0;
	Q->length = MAXQUEUE;
	for (int i = 0; i < MAXQUEUE; i++)
		Q->data[i] = (void*)malloc(20);//����20
}

void DestoryAQueue(AQueue* Q)
{
	for (int i = 0; i < MAXQUEUE; i++)
		free(Q->data[i]);
	Q->data[0] = NULL;
	free(Q);
}

Status IsFullAQueue(const AQueue* Q)//��������ж�
{
	if ((Q->rear + 1) % Q->length == Q->front)//��ʽ
		return TRUE;
	return FALSE;
}


Status IsEmptyAQueue(const AQueue* Q)//��������ж�
{
	if (LengthAQueue(Q) == 0)
		return TRUE;
	return FALSE;
}

int LengthAQueue(AQueue* Q)
{
	return (Q->rear - Q->front + Q->length) % Q->length;//��ʽ����������ʱ������һ�����е�Ԫ
}

Status EnAQueue(AQueue* Q, void* data)
{
	if (IsFullAQueue(Q))
	{
		printf("���������ˣ�\n");
		return FALSE;
	}
	memcpy(Q->data[Q->rear], data, 20);
	Q->rear = (Q->rear + 1) % Q->length;
	return TRUE;
}

Status DeAQueue(AQueue* Q)
{
	if (IsEmptyAQueue(Q))
	{
		printf("������Ϊ�գ�\n");
		return FALSE;
	}
	printf("����");
	APrint(Q->data[Q->front], datatype[Q->front]);
	printf("\n");
	Q->front = (Q->front + 1) % Q->length;//ָ������
	return TRUE;
}

void ClearAQueue(AQueue* Q)
{
	if (IsEmptyAQueue(Q))
	{
		printf("������Ϊ�գ�\n");
		return;
	}
	Q->front = Q->rear = 0;
}

Status GetHeadAQueue(AQueue* Q, void* e)
{
	if (IsEmptyAQueue(Q))
	{
		printf("����Ϊ�գ�û�ж�ͷ��\n");
		return FALSE;
	}
	memcpy(e, Q->data[Q->front], 20);
	return TRUE;
}

Status TraverseAQueue(const AQueue* Q, void (*foo)(void* q, int typeData))
{
	if (IsEmptyAQueue(Q))
	{
		printf("����Ϊ�գ�\n");
		return FALSE;
	}
	int i = 0;
	while (i < (MAXQUEUE - Q->front + Q->rear) % MAXQUEUE) 
	{
		foo(Q->data[Q->front + i], datatype[Q->front + i]);
		i = (i + 1) % MAXQUEUE;
	}
	return TRUE;
}

void APrint(void* q, int typeData)
{
	if (typeData == 2)
		printf("%7.2lf", *(double*)q);
	if (typeData == 3)
		printf("%5c", *(char*)q);
	if (typeData == 1)
		printf("%5d ", *(int*)q);
	if (typeData == 4)
		printf("%13s", (char*)q);
}





